const Carrito = {
  items: [],
  cuponAplicado: null,

  cargar() {
    try {
      const data = JSON.parse(localStorage.getItem('todostock_carrito') || '{}');
      this.items = data.items || [];
      this.cuponAplicado = data.cupon || null;
    } catch (e) {
      this.items = [];
      this.cuponAplicado = null;
    }
  },

  guardar() {
    localStorage.setItem('todostock_carrito', JSON.stringify({
      items: this.items,
      cupon: this.cuponAplicado
    }));
  },

  agregar(idProducto, cantidad = 1) {
    const producto = productos.find(p => p.id === idProducto);
    if (!producto) return { ok: false, error: 'Producto no encontrado' };
    if (cantidad <= 0) return { ok: false, error: 'Cantidad invalida' };

    const existente = this.items.find(i => i.idProducto === idProducto);
    const cantActual = existente ? existente.cantidad : 0;
    const nueva = cantActual + cantidad;

    if (nueva > producto.stock) {
      return { ok: false, error: `Solo hay ${producto.stock} en stock` };
    }

    if (existente) {
      existente.cantidad = nueva;
    } else {
      this.items.push({ idProducto, cantidad, precioUnitario: producto.precio });
    }

    this.guardar();
    Store.emit('carritoCambiado');
    return { ok: true };
  },

  actualizarCantidad(idProducto, nueva) {
    const producto = productos.find(p => p.id === idProducto);
    if (!producto) return { ok: false };
    if (nueva <= 0) return this.quitar(idProducto);
    if (nueva > producto.stock) return { ok: false, error: `Stock: ${producto.stock}` };

    const item = this.items.find(i => i.idProducto === idProducto);
    if (item) {
      item.cantidad = nueva;
      this.guardar();
      Store.emit('carritoCambiado');
    }
    return { ok: true };
  },

  quitar(idProducto) {
    this.items = this.items.filter(i => i.idProducto !== idProducto);
    this.guardar();
    Store.emit('carritoCambiado');
    return { ok: true };
  },

  vaciar() {
    this.items = [];
    this.cuponAplicado = null;
    this.guardar();
    Store.emit('carritoCambiado');
  },

  obtenerItems() {
    return this.items.map(item => {
      const producto = productos.find(p => p.id === item.idProducto);
      return {
        ...item,
        producto,
        subtotal: item.cantidad * item.precioUnitario
      };
    });
  },

  cantidadTotal() {
    return this.items.reduce((s, i) => s + i.cantidad, 0);
  },

  subtotal() {
    return this.items.reduce((s, i) => s + (i.cantidad * i.precioUnitario), 0);
  },

  ahorroProductos() {
    return this.obtenerItems().reduce((s, i) => {
      const orig = i.producto.precioOriginal;
      if (orig && orig > i.precioUnitario) {
        return s + ((orig - i.precioUnitario) * i.cantidad);
      }
      return s;
    }, 0);
  },

  descuentoCupon() {
    if (!this.cuponAplicado) return 0;
    const cupon = cupones[this.cuponAplicado];
    if (!cupon) return 0;
    if (this.subtotal() < cupon.minimo) return 0;

    if (cupon.tipo === 'porcentaje') return this.subtotal() * (cupon.valor / 100);
    if (cupon.tipo === 'fijo') return cupon.valor;
    return 0;
  },

  aplicarCupon(codigo) {
    const codigoUpper = codigo.toUpperCase().trim();
    const cupon = cupones[codigoUpper];
    if (!cupon) return { ok: false, error: 'Cupon invalido' };
    if (this.subtotal() < cupon.minimo) {
      return { ok: false, error: `Compra minima: ${formatearPrecio(cupon.minimo)}` };
    }
    this.cuponAplicado = codigoUpper;
    this.guardar();
    Store.emit('carritoCambiado');
    return { ok: true, cupon };
  },

  quitarCupon() {
    this.cuponAplicado = null;
    this.guardar();
    Store.emit('carritoCambiado');
  },

  costoEnvio(modo = 'ESTANDAR') {
    const sub = this.subtotal() - this.descuentoCupon();
    if (sub === 0) return 0;

    // Si el cupon es de envio gratis
    if (this.cuponAplicado && cupones[this.cuponAplicado]?.tipo === 'envio') return 0;

    if (sub >= CONFIG.ENVIO_GRATIS_DESDE) return 0;
    if (modo === 'EXPRESS') return CONFIG.COSTO_ENVIO_EXPRESS;
    if (modo === 'RETIRO') return CONFIG.COSTO_ENVIO_RETIRO;
    return CONFIG.COSTO_ENVIO_ESTANDAR;
  },

  total(modoEnvio = 'ESTANDAR', formaPago = 'EFECTIVO') {
    let t = this.subtotal() - this.descuentoCupon() + this.costoEnvio(modoEnvio);
    if (formaPago === 'TRANSFERENCIA') t = t * (1 - CONFIG.DESCUENTO_TRANSFERENCIA);
    return Math.max(0, t);
  },

  ahorroTotal() {
    return this.ahorroProductos() + this.descuentoCupon();
  },

  estaVacio() {
    return this.items.length === 0;
  }
};