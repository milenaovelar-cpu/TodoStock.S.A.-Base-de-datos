const Comparador = {
  ids: [],

  cargar() {
    try {
      this.ids = JSON.parse(localStorage.getItem('todostock_comparar') || '[]');
    } catch (e) { this.ids = []; }
  },

  guardar() {
    localStorage.setItem('todostock_comparar', JSON.stringify(this.ids));
  },

  toggle(idProducto) {
    if (this.ids.includes(idProducto)) {
      this.ids = this.ids.filter(id => id !== idProducto);
      this.guardar();
      Store.emit('comparadorCambiado');
      return { agregado: false };
    }
    if (this.ids.length >= CONFIG.MAX_COMPARADOR) {
      return { agregado: false, error: `Maximo ${CONFIG.MAX_COMPARADOR} productos` };
    }
    this.ids.push(idProducto);
    this.guardar();
    Store.emit('comparadorCambiado');
    return { agregado: true };
  },

  tiene(idProducto) {
    return this.ids.includes(idProducto);
  },

  obtenerProductos() {
    return this.ids.map(id => productos.find(p => p.id === id)).filter(Boolean);
  },

  limpiar() {
    this.ids = [];
    this.guardar();
    Store.emit('comparadorCambiado');
  },

  cantidad() {
    return this.ids.length;
  }
};