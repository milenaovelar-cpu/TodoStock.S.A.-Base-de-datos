function renderizarCarrito() {
  const items = document.getElementById('carritoItems');
  const vacio = document.getElementById('carritoVacio');
  const cantItems = document.getElementById('cantItemsCarrito');
  const subtotal = document.getElementById('subtotalCarrito');
  const envio = document.getElementById('envioCarrito');
  const total = document.getElementById('totalCarrito');
  const lineaDesc = document.getElementById('lineaDescuento');
  const desc = document.getElementById('descuentoCarrito');
  const btnFinalizar = document.getElementById('btnFinalizarCompra');
  const btnVaciar = document.getElementById('btnVaciarCarrito');
  const cuponActivo = document.getElementById('cuponActivo');
  const sugerencia = document.getElementById('sugerenciaCompletar');
  const ahorroBox = document.getElementById('ahorroBox');
  const ahorroTotal = document.getElementById('ahorroTotal');

  document.getElementById('badgeCarrito').textContent = Carrito.cantidadTotal();
  cantItems.textContent = Carrito.cantidadTotal();

  if (Carrito.estaVacio()) {
    items.innerHTML = '';
    vacio.classList.remove('oculto');
    btnFinalizar.disabled = true;
    btnVaciar.disabled = true;
  } else {
    vacio.classList.add('oculto');
    btnFinalizar.disabled = false;
    btnVaciar.disabled = false;

    items.innerHTML = Carrito.obtenerItems().map(item => `
      <div class="item-sidebar" data-id="${item.idProducto}">
        <div class="item-sidebar-img">${item.producto.icono}</div>
        <div class="item-sidebar-info">
          <div class="item-sidebar-nombre">${item.producto.nombre}</div>
          <div class="item-sidebar-precio">${formatearPrecio(item.precioUnitario)} c/u</div>
          <div class="item-sidebar-acciones">
            <div class="cantidad-control">
              <button data-cart-accion="restar" data-id="${item.idProducto}">-</button>
              <input type="number" min="1" max="${item.producto.stock}" value="${item.cantidad}" data-cart-input="${item.idProducto}" />
              <button data-cart-accion="sumar" data-id="${item.idProducto}">+</button>
            </div>
            <div>
              <div class="item-sidebar-subtotal">${formatearPrecio(item.subtotal)}</div>
              <button class="btn-quitar" data-cart-accion="quitar" data-id="${item.idProducto}">Quitar</button>
            </div>
          </div>
        </div>
      </div>
    `).join('');

    items.querySelectorAll('[data-cart-accion]').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = Number(btn.dataset.id);
        const accion = btn.dataset.cartAccion;
        const item = Carrito.items.find(i => i.idProducto === id);
        if (!item) return;

        if (accion === 'sumar') {
          const r = Carrito.actualizarCantidad(id, item.cantidad + 1);
          if (!r.ok) Toast.mostrar(r.error, 'error');
        } else if (accion === 'restar') {
          Carrito.actualizarCantidad(id, item.cantidad - 1);
        } else if (accion === 'quitar') {
          Carrito.quitar(id);
          Toast.mostrar('Producto eliminado', 'info');
        }
        renderizarCarrito();
        renderizarCatalogo();
      });
    });
  }

  // Sugerencia de "agrega X para envio gratis"
  const sub = Carrito.subtotal() - Carrito.descuentoCupon();
  if (sub > 0 && sub < CONFIG.ENVIO_GRATIS_DESDE) {
    const falta = CONFIG.ENVIO_GRATIS_DESDE - sub;
    sugerencia.innerHTML = `Te faltan <strong>${formatearPrecio(falta)}</strong> para envio gratis`;
    sugerencia.classList.remove('oculto');
  } else if (sub >= CONFIG.ENVIO_GRATIS_DESDE) {
    sugerencia.innerHTML = `Conseguiste envio gratis`;
    sugerencia.classList.remove('oculto');
  } else {
    sugerencia.classList.add('oculto');
  }

  // Cupon activo
  if (Carrito.cuponAplicado) {
    const cup = cupones[Carrito.cuponAplicado];
    cuponActivo.innerHTML = `
      <span>Cupon <strong>${Carrito.cuponAplicado}</strong>: ${cup.descripcion}</span>
      <button data-quitar-cupon>x</button>
    `;
    cuponActivo.classList.remove('oculto');
    cuponActivo.querySelector('[data-quitar-cupon]').addEventListener('click', () => {
      Carrito.quitarCupon();
      Toast.mostrar('Cupon removido', 'info');
      renderizarCarrito();
    });
  } else {
    cuponActivo.classList.add('oculto');
  }

  // Totales
  subtotal.textContent = formatearPrecio(Carrito.subtotal());
  const descuento = Carrito.descuentoCupon();
  if (descuento > 0) {
    lineaDesc.style.display = 'flex';
    desc.textContent = '-' + formatearPrecio(descuento);
  } else {
    lineaDesc.style.display = 'none';
  }
  const costoEnv = Carrito.costoEnvio('ESTANDAR');
  envio.textContent = costoEnv === 0 && Carrito.subtotal() > 0 ? 'Gratis' : formatearPrecio(costoEnv);
  total.textContent = formatearPrecio(Carrito.total());

  // Ahorro
  const ahorro = Carrito.ahorroTotal();
  if (ahorro > 0) {
    ahorroBox.classList.remove('oculto');
    ahorroTotal.textContent = formatearPrecio(ahorro);
  } else {
    ahorroBox.classList.add('oculto');
  }
}

function renderizarFavoritos() {
  const items = document.getElementById('favoritosItems');
  const vacio = document.getElementById('favoritosVacio');
  const lista = Favoritos.obtenerProductos();

  if (lista.length === 0) {
    items.innerHTML = '';
    vacio.classList.remove('oculto');
    return;
  }
  vacio.classList.add('oculto');

  items.innerHTML = lista.map(p => `
    <div class="item-sidebar">
      <div class="item-sidebar-img">${p.icono}</div>
      <div class="item-sidebar-info">
        <div class="item-sidebar-nombre">${p.nombre}</div>
        <div class="item-sidebar-precio">${formatearPrecio(p.precio)}</div>
        <div class="item-sidebar-acciones">
          <button class="btn btn-principal" data-fav-agregar="${p.id}">Agregar al carrito</button>
          <button class="btn-quitar" data-fav-quitar="${p.id}">Quitar</button>
        </div>
      </div>
    </div>
  `).join('');

  items.querySelectorAll('[data-fav-agregar]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = Number(btn.dataset.favAgregar);
      const r = Carrito.agregar(id, 1);
      if (r.ok) Toast.mostrar('Agregado al carrito');
      else Toast.mostrar(r.error, 'error');
    });
  });

  items.querySelectorAll('[data-fav-quitar]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = Number(btn.dataset.favQuitar);
      Favoritos.toggle(id);
      renderizarFavoritos();
      renderizarCatalogo();
      actualizarBadgeFavoritos();
    });
  });
}

function renderizarComparador() {
  const items = document.getElementById('comparadorItems');
  const vacio = document.getElementById('comparadorVacio');
  const lista = Comparador.obtenerProductos();

  if (lista.length === 0) {
    items.innerHTML = '';
    vacio.classList.remove('oculto');
    return;
  }
  vacio.classList.add('oculto');

  items.innerHTML = lista.map(p => `
    <div class="item-sidebar">
      <div class="item-sidebar-img">${p.icono}</div>
      <div class="item-sidebar-info">
        <div class="item-sidebar-nombre">${p.nombre}</div>
        <div class="item-sidebar-precio">${formatearPrecio(p.precio)} | Stock: ${p.stock}</div>
        <div class="item-sidebar-acciones">
          <button class="btn-quitar" data-cmp-quitar="${p.id}">Quitar</button>
        </div>
      </div>
    </div>
  `).join('');

  items.querySelectorAll('[data-cmp-quitar]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = Number(btn.dataset.cmpQuitar);
      Comparador.toggle(id);
      renderizarComparador();
      renderizarCatalogo();
      actualizarBadgeComparador();
    });
  });
}

function renderizarCuenta() {
  const tabHist = document.getElementById('tab-historial');
  const tabStats = document.getElementById('tab-stats');
  const pedidos = Pedidos.obtener();

  if (pedidos.length === 0) {
    tabHist.innerHTML = `
      <div class="sidebar-vacio" style="padding: 40px 0;">
        <div class="ilustracion-vacia">REC</div>
        <p>Sin pedidos aun</p>
      </div>
    `;
  } else {
    tabHist.innerHTML = pedidos.map(p => `
      <div class="pedido-historial">
        <div class="pedido-historial-header">
          <span>${p.numeroPedido}</span>
          <span class="pedido-historial-total">${formatearPrecio(p.total)}</span>
        </div>
        <div class="pedido-historial-fecha">${new Date(p.fecha).toLocaleString('es-AR')}</div>
        <div class="subtle">${p.items.length} productos | ${p.formaPago}</div>
      </div>
    `).join('');
  }

  const stats = Pedidos.estadisticas();
  tabStats.innerHTML = `
    <div class="stat-card">
      <strong>${stats.cantidad}</strong>
      <span>Pedidos realizados</span>
    </div>
    <div class="stat-card">
      <strong>${formatearPrecio(stats.total)}</strong>
      <span>Total gastado</span>
    </div>
    <div class="stat-card">
      <strong>${formatearPrecio(stats.promedio || 0)}</strong>
      <span>Promedio por pedido</span>
    </div>
    ${stats.productoTop ? `
      <div class="stat-card">
        <strong style="font-size: 1.2rem">${stats.productoTop}</strong>
        <span>Producto que mas comprás</span>
      </div>
    ` : ''}
  `;
}