function renderizarCategorias() {
  const container = document.getElementById('categoriasContainer');
  const categorias = [...new Set(productos.map(p => p.categoria))];

  container.innerHTML = `
    <button class="chip-categoria activa" data-cat="TODOS">Todos</button>
    ${categorias.map(c => `<button class="chip-categoria" data-cat="${c}">${c}</button>`).join('')}
  `;

  container.querySelectorAll('.chip-categoria').forEach(chip => {
    chip.addEventListener('click', () => {
      container.querySelectorAll('.chip-categoria').forEach(c => c.classList.remove('activa'));
      chip.classList.add('activa');
      Store.set('filtroCategoria', chip.dataset.cat);
      renderizarCatalogo();
    });
  });

  document.getElementById('statCategorias').textContent = categorias.length;
  document.getElementById('statTotalProductos').textContent = productos.length;
}

function obtenerProductosFiltrados() {
  const cat = Store.get('filtroCategoria');
  const busqueda = Store.get('busqueda').toLowerCase().trim();
  const min = Store.get('rangoMin');
  const max = Store.get('rangoMax');
  const orden = Store.get('orden');

  let lista = productos.filter(p => {
    if (cat !== 'TODOS' && p.categoria !== cat) return false;
    if (busqueda && !(p.nombre.toLowerCase().includes(busqueda) || p.codigo.toLowerCase().includes(busqueda))) return false;
    if (p.precio < min || p.precio > max) return false;
    return true;
  });

  switch (orden) {
    case 'precio-asc': lista.sort((a, b) => a.precio - b.precio); break;
    case 'precio-desc': lista.sort((a, b) => b.precio - a.precio); break;
    case 'nombre': lista.sort((a, b) => a.nombre.localeCompare(b.nombre)); break;
    case 'stock-desc': lista.sort((a, b) => b.stock - a.stock); break;
    case 'vendidos': lista.sort((a, b) => b.vendidos - a.vendidos); break;
    default:
      lista.sort((a, b) => (b.destacado ? 1 : 0) - (a.destacado ? 1 : 0));
  }
  return lista;
}

function renderizarFiltrosActivos() {
  const container = document.getElementById('filtrosActivos');
  const chips = [];

  if (Store.get('filtroCategoria') !== 'TODOS') {
    chips.push({ tipo: 'categoria', texto: Store.get('filtroCategoria') });
  }
  if (Store.get('busqueda')) {
    chips.push({ tipo: 'busqueda', texto: `Busqueda: "${Store.get('busqueda')}"` });
  }
  if (Store.get('rangoMin') > 0 || Store.get('rangoMax') < 5000) {
    chips.push({ tipo: 'precio', texto: `${formatearPrecio(Store.get('rangoMin'))} - ${formatearPrecio(Store.get('rangoMax'))}` });
  }

  container.innerHTML = chips.map(c => `
    <div class="filtro-chip">
      ${c.texto}
      <button data-quitar="${c.tipo}">x</button>
    </div>
  `).join('');

  container.querySelectorAll('[data-quitar]').forEach(btn => {
    btn.addEventListener('click', () => {
      const tipo = btn.dataset.quitar;
      if (tipo === 'categoria') {
        Store.set('filtroCategoria', 'TODOS');
        document.querySelectorAll('.chip-categoria').forEach(c => c.classList.remove('activa'));
        document.querySelector('[data-cat="TODOS"]').classList.add('activa');
      } else if (tipo === 'busqueda') {
        Store.set('busqueda', '');
        document.getElementById('inputBusquedaHero').value = '';
      } else if (tipo === 'precio') {
        Store.set('rangoMin', 0);
        Store.set('rangoMax', 5000);
        document.getElementById('rangoMin').value = 0;
        document.getElementById('rangoMax').value = 5000;
        actualizarTextoRango();
      }
      renderizarCatalogo();
    });
  });
}

function renderizarCatalogo() {
  const catalogo = document.getElementById('catalogo');
  const sinResultados = document.getElementById('sinResultados');
  const contador = document.getElementById('contadorProductos');
  const titulo = document.getElementById('tituloCatalogo');

  const lista = obtenerProductosFiltrados();
  contador.textContent = `${lista.length} ${lista.length === 1 ? 'producto' : 'productos'}`;
  titulo.textContent = Store.get('filtroCategoria') === 'TODOS' ? 'Todos los productos' : Store.get('filtroCategoria');

  catalogo.className = `catalogo vista-${Store.get('vista')}`;

  renderizarFiltrosActivos();

  if (lista.length === 0) {
    catalogo.innerHTML = '';
    sinResultados.classList.remove('oculto');
    return;
  }
  sinResultados.classList.add('oculto');

  catalogo.innerHTML = lista.map(p => tarjetaProducto(p)).join('');
  conectarTarjetas();
}

function tarjetaProducto(p) {
  const sinStock = p.stock === 0;
  const nivel = nivelStock(p.stock, p.stockMinimo);
  const pct = pctStock(p.stock, p.stockMinimo);
  const descuento = calcularDescuentoPct(p.precioOriginal, p.precio);
  const esFavorito = Favoritos.tiene(p.id);
  const enComparador = Comparador.tiene(p.id);

  const badges = p.badges.map(b => {
    const labels = { oferta: 'OFERTA', nuevo: 'NUEVO', top: 'TOP VENTAS' };
    return `<span class="tarjeta-badge badge-${b}">${labels[b]}</span>`;
  }).join('');

  const estrellas = (rating) => {
    const llenas = Math.floor(rating);
    const media = rating - llenas >= 0.5;
    let s = '';
    for (let i = 0; i < 5; i++) {
      if (i < llenas) s += '*';
      else if (i === llenas && media) s += '*';
      else s += '.';
    }
    return s;
  };

  return `
    <article class="tarjeta-producto" data-id="${p.id}">
      <div class="tarjeta-imagen" data-detalle="${p.id}">
        <div class="tarjeta-badges">${badges}</div>
        ${p.icono}
        <button class="tarjeta-fav ${esFavorito ? 'activa' : ''}" data-fav="${p.id}" title="Favorito">
          ${esFavorito ? 'FAV' : 'fav'}
        </button>
        <button class="btn-comparar ${enComparador ? 'activa' : ''}" data-comparar="${p.id}" title="Comparar">VS</button>
      </div>
      <div class="tarjeta-cuerpo">
        <div class="tarjeta-codigo">${p.codigo}</div>
        <div class="tarjeta-nombre" data-detalle="${p.id}">${p.nombre}</div>
        <div class="tarjeta-rating">
          ${estrellas(p.rating)} <span class="num">${p.rating} (${p.ratingCount})</span>
        </div>
        <div class="tarjeta-precio-box">
          <span class="tarjeta-precio">${formatearPrecio(p.precio)}</span>
          ${p.precioOriginal ? `<span class="tarjeta-precio-original">${formatearPrecio(p.precioOriginal)}</span>` : ''}
          ${descuento > 0 ? `<span class="tarjeta-descuento">-${descuento}%</span>` : ''}
        </div>
        <div class="tarjeta-stock">
          <span>${sinStock ? 'Agotado' : `Stock: ${p.stock}`}</span>
          <div class="stock-bar">
            <div class="stock-bar-fill ${nivel === 'critico' || nivel === 'bajo' ? 'bajo' : nivel === 'medio' ? 'medio' : ''}" style="width:${pct}%"></div>
          </div>
        </div>
        <div class="tarjeta-acciones">
          <div class="cantidad-control">
            <button data-accion="restar" data-id="${p.id}">-</button>
            <input type="number" min="1" max="${p.stock}" value="1" data-input-cant="${p.id}" />
            <button data-accion="sumar" data-id="${p.id}">+</button>
          </div>
          <button class="btn btn-principal" data-accion="agregar" data-id="${p.id}" ${sinStock ? 'disabled' : ''}>
            Agregar
          </button>
        </div>
      </div>
    </article>
  `;
}

function conectarTarjetas() {
  // Click en imagen o nombre abre detalle
  document.querySelectorAll('[data-detalle]').forEach(el => {
    el.addEventListener('click', (e) => {
      if (e.target.closest('[data-fav]') || e.target.closest('[data-comparar]')) return;
      abrirDetalleProducto(Number(el.dataset.detalle));
    });
  });

  // Favoritos
  document.querySelectorAll('[data-fav]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = Number(btn.dataset.fav);
      const activo = Favoritos.toggle(id);
      btn.classList.toggle('activa', activo);
      btn.textContent = activo ? 'FAV' : 'fav';
      Toast.mostrar(activo ? 'Agregado a favoritos' : 'Quitado de favoritos', activo ? 'success' : 'info');
      actualizarBadgeFavoritos();
    });
  });

  // Comparador
  document.querySelectorAll('[data-comparar]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = Number(btn.dataset.comparar);
      const r = Comparador.toggle(id);
      if (r.error) {
        Toast.mostrar(r.error, 'error');
        return;
      }
      btn.classList.toggle('activa', Comparador.tiene(id));
      Toast.mostrar(Comparador.tiene(id) ? 'Agregado al comparador' : 'Quitado del comparador', 'info');
      actualizarBadgeComparador();
    });
  });

  // Cantidad +/-
  document.querySelectorAll('[data-accion]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = Number(btn.dataset.id);
      const accion = btn.dataset.accion;
      const input = document.querySelector(`[data-input-cant="${id}"]`);
      const producto = productos.find(p => p.id === id);

      if (accion === 'sumar') {
        const actual = Number(input.value);
        if (actual < producto.stock) input.value = actual + 1;
      } else if (accion === 'restar') {
        const actual = Number(input.value);
        if (actual > 1) input.value = actual - 1;
      } else if (accion === 'agregar') {
        const cantidad = Math.max(1, Number(input.value) || 1);
        const r = Carrito.agregar(id, cantidad);
        if (r.ok) {
          Toast.mostrar(`${cantidad}x ${producto.nombre} agregado al carrito`);
          input.value = 1;
          animarBadgeCarrito();
        } else {
          Toast.mostrar(r.error, 'error');
        }
      }
    });
  });
}

function animarBadgeCarrito() {
  const badge = document.getElementById('badgeCarrito');
  badge.classList.remove('pulso');
  void badge.offsetWidth;
  badge.classList.add('pulso');
}

function actualizarBadgeFavoritos() {
  document.getElementById('badgeFavoritos').textContent = Favoritos.cantidad();
}

function actualizarBadgeComparador() {
  document.getElementById('badgeComparador').textContent = Comparador.cantidad();
  document.getElementById('cantComparador').textContent = Comparador.cantidad();
  document.getElementById('comparadorFooter').style.display = Comparador.cantidad() > 0 ? 'block' : 'none';
}

function actualizarTextoRango() {
  document.getElementById('rangoTexto').textContent =
    `${formatearPrecio(Store.get('rangoMin'))} - ${formatearPrecio(Store.get('rangoMax'))}`;
}

function renderizarSugerencias() {
  const input = document.getElementById('inputBusquedaHero');
  const container = document.getElementById('sugerenciasBusqueda');
  const q = input.value.toLowerCase().trim();

  if (!q || q.length < 2) {
    container.classList.remove('visible');
    return;
  }

  const matches = productos
    .filter(p => p.nombre.toLowerCase().includes(q) || p.codigo.toLowerCase().includes(q))
    .slice(0, 6);

  if (matches.length === 0) {
    container.classList.remove('visible');
    return;
  }

  container.innerHTML = matches.map(p => `
    <div class="sugerencia-item" data-id="${p.id}">
      <span>${p.nombre}</span>
      <small>${formatearPrecio(p.precio)}</small>
    </div>
  `).join('');
  container.classList.add('visible');

  container.querySelectorAll('[data-id]').forEach(item => {
    item.addEventListener('click', () => {
      const id = Number(item.dataset.id);
      input.value = '';
      container.classList.remove('visible');
      abrirDetalleProducto(id);
    });
  });
}