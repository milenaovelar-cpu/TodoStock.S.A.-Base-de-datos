const Pedidos = {
  lista: [],

  cargar() {
    try {
      this.lista = JSON.parse(localStorage.getItem('todostock_pedidos') || '[]');
    } catch (e) { this.lista = []; }
  },

  guardar() {
    localStorage.setItem('todostock_pedidos', JSON.stringify(this.lista));
  },

  registrar(pedido) {
    this.lista.unshift(pedido);
    this.guardar();
  },

  obtener() {
    return this.lista;
  },

  estadisticas() {
    if (this.lista.length === 0) {
      return { total: 0, cantidad: 0, promedio: 0, productoTop: null };
    }
    const total = this.lista.reduce((s, p) => s + p.total, 0);
    const productos = {};
    this.lista.forEach(p => {
      p.items.forEach(i => {
        productos[i.nombre] = (productos[i.nombre] || 0) + i.cantidad;
      });
    });
    let topNombre = null, topCant = 0;
    for (const [nombre, cant] of Object.entries(productos)) {
      if (cant > topCant) { topCant = cant; topNombre = nombre; }
    }
    return {
      total,
      cantidad: this.lista.length,
      promedio: total / this.lista.length,
      productoTop: topNombre
    };
  }
};