const Confeti = {
  canvas: null,
  ctx: null,
  particulas: [],
  animando: false,

  init() {
    this.canvas = document.getElementById('confetiCanvas');
    this.ctx = this.canvas.getContext('2d');
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
    window.addEventListener('resize', () => {
      this.canvas.width = window.innerWidth;
      this.canvas.height = window.innerHeight;
    });
  },

  lanzar() {
    const colores = ['#2563eb', '#10b981', '#f59e0b', '#ef4444', '#ec4899', '#8b5cf6'];
    this.particulas = [];
    for (let i = 0; i < 150; i++) {
      this.particulas.push({
        x: this.canvas.width / 2,
        y: this.canvas.height / 2,
        vx: (Math.random() - 0.5) * 18,
        vy: (Math.random() - 1) * 18,
        size: Math.random() * 8 + 4,
        color: colores[Math.floor(Math.random() * colores.length)],
        rotation: Math.random() * 360,
        vrotation: (Math.random() - 0.5) * 10,
        gravity: 0.4
      });
    }
    if (!this.animando) {
      this.animando = true;
      this.animar();
    }
  },

  animar() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.particulas.forEach((p, i) => {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += p.gravity;
      p.rotation += p.vrotation;

      this.ctx.save();
      this.ctx.translate(p.x, p.y);
      this.ctx.rotate(p.rotation * Math.PI / 180);
      this.ctx.fillStyle = p.color;
      this.ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
      this.ctx.restore();
    });
    this.particulas = this.particulas.filter(p => p.y < this.canvas.height + 50);
    if (this.particulas.length > 0) {
      requestAnimationFrame(() => this.animar());
    } else {
      this.animando = false;
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
  }
};