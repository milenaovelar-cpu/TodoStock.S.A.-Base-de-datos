// ============ ABRIR/CERRAR SIDEBARS ============
function abrirSidebar(id) {
  cerrarTodosLosSidebars();
  document.getElementById(id).classList.add('abierto');
  document.getElementById('overlay').classList.add('activo');
}

function cerrarTodosLosSidebars() {
  document.querySelectorAll('.sidebar').forEach(s => s.classList.remove('abierto'));
  document.getElementById('overlay').classList.remove('activo');
}

// ============ INICIALIZACION ============
document.addEventListener('DOMContentLoaded', () => {
  // Cargar estado persistido
  Store.cargarTema();
  Carrito.cargar();
  Favoritos.cargar();
  Comparador.cargar();
  Pedidos.cargar();
  Confeti.init();

  // Renderizar UI inicial
  renderizarCategorias();
  renderizarCatalogo();
  renderizarCarrito();
  renderizarFavoritos();
  renderizarComparador();
  renderizarCuenta();
  actualizarBadgeFavoritos();
  actualizarBadgeComparador();

  // ===== EVENTOS GLOBALES =====

  // Toggle tema
  document.getElementById('btnToggleTema').addEventListener('click', () => Store.toggleTema());

  // Aperturas de sidebars
  document.getElementById('btnAbrirCarrito').addEventListener('click', () => abrirSidebar('carritoSidebar'));
  document.getElementById('btnAbrirFavoritos').addEventListener('click', () => {
    renderizarFavoritos();
    abrirSidebar('favoritosSidebar');
  });
  document.getElementById('btnAbrirComparador').addEventListener('click', () => {
    renderizarComparador();
    abrirSidebar('comparadorSidebar');
  });
  document.getElementById('btnAbrirCuenta').addEventListener('click', () => {
    renderizarCuenta();
    abrirSidebar('cuentaSidebar');
  });

  // Cerrar sidebars
  document.querySelectorAll('[data-cerrar-sidebar]').forEach(btn => {
    btn.addEventListener('click', () => cerrarTodosLosSidebars());
  });
  document.getElementById('overlay').addEventListener('click', cerrarTodosLosSidebars);

  // Tabs de cuenta
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('activa'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('activo'));
      btn.classList.add('activa');
      document.getElementById(`tab-${btn.dataset.tab}`).classList.add('activo');
    });
  });

  // ===== BUSCADOR =====
  const inputBusqueda = document.getElementById('inputBusquedaHero');
  let timeoutBusqueda;
  inputBusqueda.addEventListener('input', (e) => {
    clearTimeout(timeoutBusqueda);
    timeoutBusqueda = setTimeout(() => {
      Store.set('busqueda', e.target.value);
      renderizarSugerencias();
      renderizarCatalogo();
    }, 200);
  });
  inputBusqueda.addEventListener('blur', () => {
    setTimeout(() => document.getElementById('sugerenciasBusqueda').classList.remove('visible'), 200);
  });
  document.getElementById('btnBuscarHero').addEventListener('click', () => {
    Store.set('busqueda', inputBusqueda.value);
    renderizarCatalogo();
    window.scrollTo({ top: document.querySelector('main').offsetTop - 100, behavior: 'smooth' });
  });

  // ===== ORDEN =====
  document.getElementById('ordenamiento').addEventListener('change', (e) => {
    Store.set('orden', e.target.value);
    renderizarCatalogo();
  });

  // ===== VISTA GRILLA/LISTA =====
  document.querySelectorAll('.vista-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.vista-btn').forEach(b => b.classList.remove('activa'));
      btn.classList.add('activa');
      Store.set('vista', btn.dataset.vista);
      renderizarCatalogo();
    });
  });

  // ===== RANGO DE PRECIO =====
  const rangoMin = document.getElementById('rangoMin');
  const rangoMax = document.getElementById('rangoMax');
  function actualizarRango() {
    let min = Number(rangoMin.value);
    let max = Number(rangoMax.value);
    if (min > max) { [min, max] = [max, min]; }
    Store.set('rangoMin', min);
    Store.set('rangoMax', max);
    actualizarTextoRango();
    clearTimeout(rangoMin._t);
    rangoMin._t = setTimeout(() => renderizarCatalogo(), 200);
  }
  rangoMin.addEventListener('input', actualizarRango);
  rangoMax.addEventListener('input', actualizarRango);

  // ===== CARRITO =====
  document.getElementById('btnVaciarCarrito').addEventListener('click', () => {
    if (Carrito.estaVacio()) return;
    if (confirm('Vaciar el carrito?')) {
      Carrito.vaciar();
      renderizarCarrito();
      Toast.mostrar('Carrito vaciado', 'info');
    }
  });

  document.getElementById('btnFinalizarCompra').addEventListener('click', abrirCheckout);

  // Cupon
  document.getElementById('btnAplicarCupon').addEventListener('click', () => {
    const codigo = document.getElementById('inputCupon').value;
    if (!codigo.trim()) return;
    const r = Carrito.aplicarCupon(codigo);
    if (r.ok) {
      Toast.mostrar(`Cupon aplicado: ${r.cupon.descripcion}`, 'success');
      document.getElementById('inputCupon').value = '';
      renderizarCarrito();
    } else {
      Toast.mostrar(r.error, 'error');
    }
  });

  // ===== COMPARADOR =====
  document.getElementById('btnAbrirModalComparar').addEventListener('click', () => {
    cerrarTodosLosSidebars();
    abrirComparador();
  });
  document.getElementById('btnLimpiarComparador').addEventListener('click', () => {
    Comparador.limpiar();
    renderizarComparador();
    renderizarCatalogo();
    actualizarBadgeComparador();
    Toast.mostrar('Comparador vaciado', 'info');
  });

  // ===== CHECKOUT WIZARD =====
  document.getElementById('btnPasoSiguiente').addEventListener('click', () => Wizard.siguiente());
  document.getElementById('btnPasoAnterior').addEventListener('click', () => Wizard.anterior());
  document.getElementById('btnCerrarCheckout').addEventListener('click', cerrarCheckout);
  document.getElementById('formCheckout').addEventListener('submit', procesarCheckout);
  document.getElementById('modalCheckout').addEventListener('click', (e) => {
    if (e.target.id === 'modalCheckout') cerrarCheckout();
  });
  // Re-render resumen al cambiar opciones de envio o pago
  document.querySelectorAll('input[name="modoEnvio"], input[name="formaPago"]').forEach(r => {
    r.addEventListener('change', () => Wizard.renderResumen());
  });

  // ===== CONFIRMACION =====
  document.getElementById('btnCerrarConfirmacion').addEventListener('click', () => {
    document.getElementById('modalConfirmacion').classList.remove('activo');
  });

  // ===== LIMPIAR FILTROS =====
  document.getElementById('btnLimpiarFiltros').addEventListener('click', () => {
    Store.set('filtroCategoria', 'TODOS');
    Store.set('busqueda', '');
    Store.set('rangoMin', 0);
    Store.set('rangoMax', 5000);
    document.getElementById('inputBusquedaHero').value = '';
    rangoMin.value = 0;
    rangoMax.value = 5000;
    actualizarTextoRango();
    document.querySelectorAll('.chip-categoria').forEach(c => c.classList.remove('activa'));
    document.querySelector('[data-cat="TODOS"]').classList.add('activa');
    renderizarCatalogo();
  });

  // ===== BOTON SCROLL TOP =====
  const btnScroll = document.getElementById('btnScrollTop');
  window.addEventListener('scroll', () => {
    btnScroll.classList.toggle('visible', window.scrollY > 400);
  });
  btnScroll.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

  // ===== ATAJOS DE TECLADO =====
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      cerrarTodosLosSidebars();
      cerrarCheckout();
      cerrarModalProducto();
      document.getElementById('modalConfirmacion').classList.remove('activo');
      document.getElementById('modalComparar').classList.remove('activo');
    }
    if (e.ctrlKey && e.key === 'k') {
      e.preventDefault();
      inputBusqueda.focus();
    }
    if (e.ctrlKey && e.key === 'm') {
      e.preventDefault();
      Store.toggleTema();
    }
  });

  // ===== STORE OBSERVERS =====
  Store.on('carritoCambiado', renderizarCarrito);
  Store.on('favoritosCambiado', () => {
    renderizarFavoritos();
    actualizarBadgeFavoritos();
    renderizarCatalogo();
  });
  Store.on('comparadorCambiado', () => {
    renderizarComparador();
    actualizarBadgeComparador();
    renderizarCatalogo();
  });

  // Inicializar texto del rango
  actualizarTextoRango();
});