const Favoritos = {
  ids: new Set(),

  cargar() {
    try {
      const data = JSON.parse(localStorage.getItem('todostock_favoritos') || '[]');
      this.ids = new Set(data);
    } catch (e) { this.ids = new Set(); }
  },

  guardar() {
    localStorage.setItem('todostock_favoritos', JSON.stringify([...this.ids]));
  },

  toggle(idProducto) {
    if (this.ids.has(idProducto)) {
      this.ids.delete(idProducto);
    } else {
      this.ids.add(idProducto);
    }
    this.guardar();
    Store.emit('favoritosCambiado');
    return this.ids.has(idProducto);
  },

  tiene(idProducto) {
    return this.ids.has(idProducto);
  },

  obtenerProductos() {
    return [...this.ids]
      .map(id => productos.find(p => p.id === id))
      .filter(Boolean);
  },

  cantidad() {
    return this.ids.size;
  }
};