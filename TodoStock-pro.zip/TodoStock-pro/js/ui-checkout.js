const Wizard = {
  paso: 1,
  totalPasos: 3,

  iniciar() {
    this.paso = 1;
    this.actualizarUI();
    this.renderResumen();
  },

  siguiente() {
    if (!this.validarPaso(this.paso)) return;
    if (this.paso < this.totalPasos) {
      this.paso++;
      this.actualizarUI();
      this.renderResumen();
    }
  },

  anterior() {
    if (this.paso > 1) {
      this.paso--;
      this.actualizarUI();
    }
  },

  validarPaso(paso) {
    const form = document.getElementById('formCheckout');
    const inputs = form.querySelectorAll(`[data-contenido="${paso}"] [required]`);
    let valido = true;

    inputs.forEach(input => {
      const errorEl = input.parentElement.querySelector('.form-error');
      if (!input.checkValidity()) {
        if (errorEl) errorEl.textContent = input.validationMessage || 'Campo obligatorio';
        input.classList.add('shake');
        setTimeout(() => input.classList.remove('shake'), 500);
        valido = false;
      } else {
        if (errorEl) errorEl.textContent = '';
      }
    });

    if (!valido) Toast.mostrar('Revisa los datos del formulario', 'error');
    return valido;
  },

  actualizarUI() {
    // Pasos visuales
    document.querySelectorAll('.wizard-paso').forEach(p => {
      const numPaso = Number(p.dataset.paso);
      p.classList.remove('activo', 'completado');
      if (numPaso === this.paso) p.classList.add('activo');
      else if (numPaso < this.paso) p.classList.add('completado');
    });

    // Contenidos
    document.querySelectorAll('.wizard-content').forEach(c => {
      c.classList.toggle('activo', Number(c.dataset.contenido) === this.paso);
    });

    // Botones
    document.getElementById('btnPasoAnterior').style.display = this.paso > 1 ? 'block' : 'none';
    document.getElementById('btnPasoSiguiente').style.display = this.paso < this.totalPasos ? 'block' : 'none';
    document.getElementById('btnConfirmarPedido').style.display = this.paso === this.totalPasos ? 'block' : 'none';
  },

  renderResumen() {
    const resumen = document.getElementById('resumenItemsCheckout');
    const total = document.getElementById('totalCheckout');
    const modoEnvio = document.querySelector('input[name="modoEnvio"]:checked')?.value || 'ESTANDAR';
    const formaPago = document.querySelector('input[name="formaPago"]:checked')?.value || 'EFECTIVO';

    resumen.innerHTML = Carrito.obtenerItems().map(item => `
      <div class="resumen-item-checkout">
        <span>${item.cantidad}x ${item.producto.nombre}</span>
        <span>${formatearPrecio(item.subtotal)}</span>
      </div>
    `).join('') + (Carrito.descuentoCupon() > 0 ? `
      <div class="resumen-item-checkout">
        <span>Cupon ${Carrito.cuponAplicado}</span>
        <span style="color:var(--secundario)">-${formatearPrecio(Carrito.descuentoCupon())}</span>
      </div>
    ` : '') + `
      <div class="resumen-item-checkout">
        <span>Envio (${modoEnvio})</span>
        <span>${Carrito.costoEnvio(modoEnvio) === 0 ? 'Gratis' : formatearPrecio(Carrito.costoEnvio(modoEnvio))}</span>
      </div>
      ${formaPago === 'TRANSFERENCIA' ? `
        <div class="resumen-item-checkout">
          <span>Descuento transferencia (5%)</span>
          <span style="color:var(--secundario)">aplicado</span>
        </div>
      ` : ''}
    `;

    total.textContent = formatearPrecio(Carrito.total(modoEnvio, formaPago));
  }
};

function abrirCheckout() {
  if (Carrito.estaVacio()) {
    Toast.mostrar('El carrito esta vacio', 'error');
    return;
  }
  document.getElementById('modalCheckout').classList.add('activo');
  Wizard.iniciar();
}

function cerrarCheckout() {
  document.getElementById('modalCheckout').classList.remove('activo');
}

function generarNumeroPedido() {
  const anio = new Date().getFullYear();
  const random = Math.floor(Math.random() * 9000) + 1000;
  return `TS-${anio}-${random}`;
}

function procesarCheckout(e) {
  e.preventDefault();
  if (!Wizard.validarPaso(3)) return;

  const form = document.getElementById('formCheckout');
  const fd = new FormData(form);
  const modoEnvio = fd.get('modoEnvio');
  const formaPago = fd.get('formaPago');

  const pedido = {
    numeroPedido: generarNumeroPedido(),
    fecha: new Date().toISOString(),
    razonSocial: fd.get('razonSocial'),
    cuit: fd.get('cuit'),
    email: fd.get('email'),
    telefono: fd.get('telefono'),
    direccion: fd.get('direccion'),
    ciudad: fd.get('ciudad'),
    provincia: fd.get('provincia'),
    cp: fd.get('cp'),
    modoEnvio,
    formaPago,
    observaciones: fd.get('observaciones'),
    items: Carrito.obtenerItems().map(i => ({
      codigo: i.producto.codigo,
      nombre: i.producto.nombre,
      cantidad: i.cantidad,
      precioUnitario: i.precioUnitario,
      subtotal: i.subtotal
    })),
    subtotal: Carrito.subtotal(),
    descuentoCupon: Carrito.descuentoCupon(),
    cuponAplicado: Carrito.cuponAplicado,
    envio: Carrito.costoEnvio(modoEnvio),
    total: Carrito.total(modoEnvio, formaPago)
  };

  // Guardar pedido
  Pedidos.registrar(pedido);

  // Descontar stock simulado
  Carrito.items.forEach(item => {
    const p = productos.find(pr => pr.id === item.idProducto);
    if (p) p.stock = Math.max(0, p.stock - item.cantidad);
  });

  // Vaciar carrito
  Carrito.vaciar();
  form.reset();
  cerrarCheckout();
  cerrarTodosLosSidebars();

  // Re-renderizar
  renderizarCatalogo();
  renderizarCarrito();
  renderizarCuenta();

  // Confeti + confirmacion
  Confeti.lanzar();
  setTimeout(() => {
    document.getElementById('numeroPedido').textContent = pedido.numeroPedido;
    document.getElementById('emailConfirmacion').textContent = pedido.email;
    document.getElementById('totalConfirmacion').textContent = formatearPrecio(pedido.total);
    document.getElementById('cantidadConfirmacion').textContent = pedido.items.length;
    document.getElementById('modalConfirmacion').classList.add('activo');
  }, 400);
}