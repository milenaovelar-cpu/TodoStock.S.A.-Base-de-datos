const productos = [
  {
    id: 1, codigo: 'LIM-001', nombre: 'Lavandina Concentrada 5L',
    categoria: 'Limpieza', precio: 1800, precioOriginal: 2100,
    stock: 240, stockMinimo: 50, unidad: 'LT', icono: 'LV',
    descripcion: 'Lavandina industrial concentrada para uso comercial. Ideal para desinfectar superficies, pisos y baños. Activa contra virus y bacterias.',
    rating: 4.5, ratingCount: 124, vendidos: 850,
    badges: ['top'], destacado: true
  },
  {
    id: 2, codigo: 'LIM-002', nombre: 'Detergente Industrial 10L',
    categoria: 'Limpieza', precio: 3800, precioOriginal: 4500,
    stock: 80, stockMinimo: 30, unidad: 'LT', icono: 'DT',
    descripcion: 'Detergente concentrado lavavajilla profesional. Alto poder desengrasante. Rinde hasta 1000 platos.',
    rating: 4.7, ratingCount: 89, vendidos: 420,
    badges: ['oferta']
  },
  {
    id: 3, codigo: 'LIM-003', nombre: 'Trapo de Piso Industrial x10',
    categoria: 'Limpieza', precio: 1200,
    stock: 350, stockMinimo: 100, unidad: 'PACK', icono: 'TP',
    descripcion: 'Pack 10 trapos rejilla de alto absorbente, reutilizables.',
    rating: 4.2, ratingCount: 67, vendidos: 1200,
    badges: []
  },
  {
    id: 4, codigo: 'LIM-004', nombre: 'Desinfectante Pino 1L',
    categoria: 'Limpieza', precio: 550,
    stock: 420, stockMinimo: 80, unidad: 'LT', icono: 'DP',
    descripcion: 'Desinfectante aromatico con fragancia pino. Limpia y perfuma.',
    rating: 4.6, ratingCount: 203, vendidos: 1800,
    badges: ['top']
  },
  {
    id: 5, codigo: 'LIM-005', nombre: 'Esponja Doble Faz Pack x12',
    categoria: 'Limpieza', precio: 900, precioOriginal: 1100,
    stock: 30, stockMinimo: 50, unidad: 'PACK', icono: 'ES',
    descripcion: 'Pack 12 esponjas con cara abrasiva amarilla y verde.',
    rating: 4.3, ratingCount: 45, vendidos: 320,
    badges: ['oferta']
  },
  {
    id: 6, codigo: 'LIM-006', nombre: 'Limpiavidrios 1L Spray',
    categoria: 'Limpieza', precio: 480,
    stock: 200, stockMinimo: 60, unidad: 'UN', icono: 'LV',
    descripcion: 'Limpiavidrios con gatillo pulverizador. Secado rapido sin marcas.',
    rating: 4.4, ratingCount: 88, vendidos: 540,
    badges: []
  },
  {
    id: 7, codigo: 'PAP-001', nombre: 'Papel Higienico x4 Hojas Dobles',
    categoria: 'Papeleria', precio: 750,
    stock: 600, stockMinimo: 100, unidad: 'PACK', icono: 'PH',
    descripcion: 'Pack 4 rollos de papel higienico doble hoja. 50m por rollo.',
    rating: 4.8, ratingCount: 312, vendidos: 2400,
    badges: ['top']
  },
  {
    id: 8, codigo: 'PAP-002', nombre: 'Servilletas x100',
    categoria: 'Papeleria', precio: 450,
    stock: 380, stockMinimo: 60, unidad: 'CAJA', icono: 'SV',
    descripcion: 'Caja 100 servilletas blancas 24x24cm.',
    rating: 4.1, ratingCount: 56, vendidos: 880,
    badges: []
  },
  {
    id: 9, codigo: 'PAP-003', nombre: 'Rollo de Cocina x2',
    categoria: 'Papeleria', precio: 680,
    stock: 250, stockMinimo: 80, unidad: 'PACK', icono: 'RC',
    descripcion: 'Pack 2 rollos cocina de alto absorbente.',
    rating: 4.5, ratingCount: 102, vendidos: 760,
    badges: []
  },
  {
    id: 10, codigo: 'BOL-001', nombre: 'Bolsa Residuo 80L x10',
    categoria: 'Bolsas', precio: 850,
    stock: 180, stockMinimo: 50, unidad: 'PACK', icono: 'BR',
    descripcion: 'Pack 10 bolsas residuo negras reforzadas 80L.',
    rating: 4.6, ratingCount: 78, vendidos: 690,
    badges: ['nuevo']
  },
  {
    id: 11, codigo: 'BOL-002', nombre: 'Bolsa Camiseta x100',
    categoria: 'Bolsas', precio: 320,
    stock: 12, stockMinimo: 100, unidad: 'PACK', icono: 'BC',
    descripcion: 'Pack 100 bolsas camiseta blancas medianas. Asas reforzadas.',
    rating: 4.0, ratingCount: 34, vendidos: 1100,
    badges: []
  },
  {
    id: 12, codigo: 'EQU-001', nombre: 'Escoba de Cerdas Duras',
    categoria: 'Equipamiento', precio: 1100,
    stock: 75, stockMinimo: 30, unidad: 'UN', icono: 'EC',
    descripcion: 'Escoba con cerdas de plastico duro y palo largo de madera.',
    rating: 4.3, ratingCount: 41, vendidos: 230,
    badges: []
  },
  {
    id: 13, codigo: 'EQU-002', nombre: 'Balde 12L con Escurridor',
    categoria: 'Equipamiento', precio: 1450, precioOriginal: 1700,
    stock: 45, stockMinimo: 20, unidad: 'UN', icono: 'BA',
    descripcion: 'Balde plastico de 12L con escurridor integrado. Resistente.',
    rating: 4.5, ratingCount: 63, vendidos: 180,
    badges: ['oferta']
  },
  {
    id: 14, codigo: 'EQU-003', nombre: 'Mopa de Microfibra',
    categoria: 'Equipamiento', precio: 980,
    stock: 60, stockMinimo: 30, unidad: 'UN', icono: 'MM',
    descripcion: 'Mopa con paño microfibra reemplazable. Sistema de auto-escurrido.',
    rating: 4.7, ratingCount: 92, vendidos: 310,
    badges: ['nuevo']
  },
  {
    id: 15, codigo: 'LIM-007', nombre: 'Jabon Liquido para Manos 5L',
    categoria: 'Limpieza', precio: 2200,
    stock: 90, stockMinimo: 40, unidad: 'LT', icono: 'JL',
    descripcion: 'Jabon liquido cremoso para dispenser. Fragancia neutra. Hidratante.',
    rating: 4.4, ratingCount: 71, vendidos: 290,
    badges: []
  },
  {
    id: 16, codigo: 'LIM-008', nombre: 'Alcohol en Gel 1L',
    categoria: 'Limpieza', precio: 1300,
    stock: 150, stockMinimo: 50, unidad: 'LT', icono: 'AG',
    descripcion: 'Alcohol en gel sanitizante 70%. Anti-bacterial.',
    rating: 4.8, ratingCount: 245, vendidos: 1500,
    badges: ['top']
  }
];

// ============ REVIEWS ============
const reviews = {
  1: [
    { autor: 'Maria G.', rating: 5, fecha: '2026-04-10', texto: 'Excelente producto, lo uso para mi panaderia. Concentrado y rinde mucho.' },
    { autor: 'Carlos P.', rating: 4, fecha: '2026-03-22', texto: 'Buen producto. El envio fue rapido.' }
  ],
  4: [
    { autor: 'Ana M.', rating: 5, fecha: '2026-05-01', texto: 'Aroma agradable y desinfecta muy bien. Lo recomiendo.' }
  ],
  7: [
    { autor: 'Roberto F.', rating: 5, fecha: '2026-04-28', texto: 'Buena calidad y precio mayorista insuperable.' },
    { autor: 'Lucia D.', rating: 5, fecha: '2026-04-15', texto: 'Lo compro siempre para mi local. Recomendado.' }
  ]
};

// ============ CUPONES ============
const cupones = {
  'BIENVENIDA10': { tipo: 'porcentaje', valor: 10, descripcion: '10% off en tu primer compra', minimo: 0 },
  'LIMPIEZA20': { tipo: 'porcentaje', valor: 20, descripcion: '20% off en limpieza', minimo: 5000 },
  'ENVIOGRATIS': { tipo: 'envio', valor: 0, descripcion: 'Envio gratis', minimo: 10000 },
  'AHORRO5000': { tipo: 'fijo', valor: 5000, descripcion: '$5000 de descuento', minimo: 30000 }
};

// ============ CONFIGURACION ============
const CONFIG = {
  COSTO_ENVIO_ESTANDAR: 2500,
  COSTO_ENVIO_EXPRESS: 4500,
  COSTO_ENVIO_RETIRO: 0,
  ENVIO_GRATIS_DESDE: 50000,
  DESCUENTO_TRANSFERENCIA: 0.05,
  MAX_COMPARADOR: 3
};