function abrirDetalleProducto(idProducto) {
  const p = productos.find(x => x.id === idProducto);
  if (!p) return;

  const productoReviews = reviews[p.id] || [];
  const descuento = calcularDescuentoPct(p.precioOriginal, p.precio);
  const relacionados = productos
    .filter(x => x.categoria === p.categoria && x.id !== p.id)
    .slice(0, 4);

  const content = document.getElementById('modalProductoContent');
  content.innerHTML = `
    <button class="btn-cerrar" data-cerrar-modal>x</button>
    <div class="detalle-producto">
      <div class="detalle-imagen">${p.icono}</div>
      <div class="detalle-info">
        <span class="detalle-categoria">${p.categoria}</span>
        <h2>${p.nombre}</h2>
        <div class="tarjeta-codigo">${p.codigo}</div>
        <div class="tarjeta-rating">
          ${'*'.repeat(Math.floor(p.rating))}${'.'.repeat(5 - Math.floor(p.rating))}
          <span class="num">${p.rating} (${p.ratingCount} reviews)</span>
        </div>
        <div class="detalle-precio-box">
          <span class="detalle-precio">${formatearPrecio(p.precio)}</span>
          ${p.precioOriginal ? `<span class="tarjeta-precio-original">${formatearPrecio(p.precioOriginal)}</span>` : ''}
          ${descuento > 0 ? `<span class="tarjeta-descuento">-${descuento}%</span>` : ''}
        </div>
        <p class="detalle-descripcion">${p.descripcion}</p>
        <div class="tarjeta-stock">
          <span>${p.stock === 0 ? 'Agotado' : `Disponible: ${p.stock} ${p.unidad}`}</span>
        </div>
        <div class="detalle-acciones">
          <div class="cantidad-control">
            <button data-detalle-accion="restar">-</button>
            <input type="number" id="cantidadDetalle" min="1" max="${p.stock}" value="1" />
            <button data-detalle-accion="sumar">+</button>
          </div>
          <button class="btn btn-principal" data-agregar-detalle="${p.id}" ${p.stock === 0 ? 'disabled' : ''}>
            Agregar al carrito
          </button>
        </div>
      </div>
    </div>

    ${productoReviews.length > 0 ? `
      <div class="reviews">
        <h3>Opiniones (${productoReviews.length})</h3>
        ${productoReviews.map(r => `
          <div class="review">
            <div class="review-header">
              <span class="review-autor">${r.autor}</span>
              <span class="review-rating">${'*'.repeat(r.rating)}</span>
            </div>
            <div class="review-fecha">${r.fecha}</div>
            <p>${r.texto}</p>
          </div>
        `).join('')}
      </div>
    ` : ''}

    ${relacionados.length > 0 ? `
      <div class="reviews">
        <h3>Productos relacionados</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px;">
          ${relacionados.map(r => `
            <div class="item-sidebar" style="cursor: pointer; flex-direction: column;" data-relacionado="${r.id}">
              <div class="item-sidebar-img" style="width: 100%; height: 80px;">${r.icono}</div>
              <div style="text-align: center;">
                <div style="font-size: 0.85rem; font-weight: 600;">${r.nombre}</div>
                <div style="color: var(--primario); font-weight: 700;">${formatearPrecio(r.precio)}</div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    ` : ''}
  `;

  document.getElementById('modalProducto').classList.add('activo');

  // Eventos
  content.querySelector('[data-cerrar-modal]').addEventListener('click', cerrarModalProducto);

  content.querySelectorAll('[data-detalle-accion]').forEach(btn => {
    btn.addEventListener('click', () => {
      const input = document.getElementById('cantidadDetalle');
      const actual = Number(input.value);
      if (btn.dataset.detalleAccion === 'sumar' && actual < p.stock) input.value = actual + 1;
      if (btn.dataset.detalleAccion === 'restar' && actual > 1) input.value = actual - 1;
    });
  });

  content.querySelector('[data-agregar-detalle]')?.addEventListener('click', () => {
    const cantidad = Number(document.getElementById('cantidadDetalle').value) || 1;
    const r = Carrito.agregar(p.id, cantidad);
    if (r.ok) {
      Toast.mostrar(`${cantidad}x ${p.nombre} agregado`);
      cerrarModalProducto();
    } else {
      Toast.mostrar(r.error, 'error');
    }
  });

  content.querySelectorAll('[data-relacionado]').forEach(el => {
    el.addEventListener('click', () => {
      const id = Number(el.dataset.relacionado);
      cerrarModalProducto();
      setTimeout(() => abrirDetalleProducto(id), 300);
    });
  });
}

function cerrarModalProducto() {
  document.getElementById('modalProducto').classList.remove('activo');
}

function abrirComparador() {
  const lista = Comparador.obtenerProductos();
  if (lista.length === 0) {
    Toast.mostrar('Agrega al menos 2 productos para comparar', 'info');
    return;
  }

  const content = document.getElementById('modalCompararContent');
  const cols = `1fr ${'1fr '.repeat(lista.length)}`;

  const fila = (label, valores) => `
    <div class="comparar-fila" style="grid-template-columns: ${cols}">
      <div class="comparar-label">${label}</div>
      ${valores.map(v => `<div class="comparar-celda">${v}</div>`).join('')}
    </div>
  `;

  content.innerHTML = `
    <button class="btn-cerrar" data-cerrar-modal>x</button>
    <h2>Comparar productos</h2>
    <div class="comparar-grid">
      ${fila('', lista.map(p => `<div class="comparar-img-mini">${p.icono}</div>`))}
      ${fila('Nombre', lista.map(p => `<strong>${p.nombre}</strong>`))}
      ${fila('Categoria', lista.map(p => p.categoria))}
      ${fila('Codigo', lista.map(p => p.codigo))}
      ${fila('Precio', lista.map(p => `<span class="comparar-precio">${formatearPrecio(p.precio)}</span>`))}
      ${fila('Stock', lista.map(p => `${p.stock} ${p.unidad}`))}
      ${fila('Rating', lista.map(p => `${p.rating} (${p.ratingCount})`))}
      ${fila('Vendidos', lista.map(p => p.vendidos))}
      ${fila('Descripcion', lista.map(p => `<span style="font-size:0.85rem">${p.descripcion}</span>`))}
      ${fila('Agregar', lista.map(p => `<button class="btn btn-principal" data-cmp-add="${p.id}" ${p.stock === 0 ? 'disabled' : ''}>Al carrito</button>`))}
    </div>
  `;

  document.getElementById('modalComparar').classList.add('activo');

  content.querySelector('[data-cerrar-modal]').addEventListener('click', () => {
    document.getElementById('modalComparar').classList.remove('activo');
  });

  content.querySelectorAll('[data-cmp-add]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = Number(btn.dataset.cmpAdd);
      const r = Carrito.agregar(id, 1);
      if (r.ok) Toast.mostrar('Agregado al carrito');
      else Toast.mostrar(r.error, 'error');
    });
  });
}