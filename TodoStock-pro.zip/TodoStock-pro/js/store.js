// ============ STORE GLOBAL CON OBSERVERS ============
const Store = {
  estado: {
    filtroCategoria: 'TODOS',
    busqueda: '',
    orden: 'relevancia',
    vista: 'grilla',
    rangoMin: 0,
    rangoMax: 5000,
    tema: 'light'
  },

  listeners: {},

  on(evento, callback) {
    if (!this.listeners[evento]) this.listeners[evento] = [];
    this.listeners[evento].push(callback);
  },

  emit(evento, data) {
    if (this.listeners[evento]) {
      this.listeners[evento].forEach(cb => cb(data));
    }
  },

  set(clave, valor) {
    this.estado[clave] = valor;
    this.emit('cambio', { clave, valor });
    this.emit(`cambio:${clave}`, valor);
  },

  get(clave) {
    return this.estado[clave];
  },

  cargarTema() {
    const guardado = localStorage.getItem('todostock_tema') || 'light';
    this.estado.tema = guardado;
    document.documentElement.setAttribute('data-theme', guardado);
  },

  toggleTema() {
    const nuevo = this.estado.tema === 'light' ? 'dark' : 'light';
    this.estado.tema = nuevo;
    document.documentElement.setAttribute('data-theme', nuevo);
    localStorage.setItem('todostock_tema', nuevo);
    this.emit('temaCambiado', nuevo);
  }
};

const Toast = {
  mostrar(mensaje, tipo = 'success', duracion = 2800) {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${tipo}`;
    toast.textContent = mensaje;
    container.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('fadeOut');
      setTimeout(() => toast.remove(), 300);
    }, duracion);
  }
};

function formatearPrecio(monto) {
  return '$' + Math.round(monto).toLocaleString('es-AR');
}

function calcularDescuentoPct(precioOriginal, precioActual) {
  if (!precioOriginal || precioOriginal <= precioActual) return 0;
  return Math.round((1 - precioActual / precioOriginal) * 100);
}

function nivelStock(stock, minimo) {
  if (stock === 0) return 'agotado';
  if (stock <= minimo / 2) return 'critico';
  if (stock <= minimo) return 'bajo';
  if (stock <= minimo * 2) return 'medio';
  return 'alto';
}

function pctStock(stock, minimo) {
  if (stock === 0) return 0;
  const max = Math.max(minimo * 5, 100);
  return Math.min(100, (stock / max) * 100);
}