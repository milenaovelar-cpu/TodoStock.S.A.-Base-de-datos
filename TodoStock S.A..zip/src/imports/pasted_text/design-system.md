🎨 IDENTIDAD VISUAL
Paleta de colores
NombreHEXUsoVerde Principal#1A6B4ABotones primarios, header, acentosVerde Claro#E8F5EEFondos de cards, badgesVerde Oscuro#0D3D28Footer, topbar, textos importantesAmarillo Acento#F5A623Ofertas, badges, CTAs secundariosGris Claro#F4F4F0Fondo general de páginaGris Medio#9B9B93Textos secundarios, bordesBlanco#FFFFFFCards, header, fondosRojo Alerta#E8453CDescuentos, errores, urgencia
Tipografía
RolFamiliaPesoTamañoDisplay / HeroSyne800 ExtraBold40–48pxTítulos de secciónSyne700 Bold22–28pxSubtítulos / NavSyne600 SemiBold14–16pxCuerpo de textoDM Sans400 Regular14–16pxPreciosSyne700 Bold18–22pxLabels / badgesSyne600 SemiBold10–12px
Espaciado

Padding de sección: 64px vertical / 24px horizontal
Gap entre cards: 16px
Border radius cards: 12px
Border radius botones: 8px (primarios) / 20px (pills/chips)
Border radius inputs: 8px

Sombras

Card hover: 0px 4px 20px rgba(0,0,0,0.10)
Dropdown: 0px 8px 24px rgba(0,0,0,0.12)
Header sticky: 0px 2px 8px rgba(0,0,0,0.08)


📐 FRAMES / ARTBOARDS
FrameTamañoNotasDesktop Home1440 × 5200pxFrame principalDropdown abierto1440 × 900pxEstado hover en "Productos"Carrito abierto1440 × 900pxDrawer desde la derechaModal producto1440 × 900pxOverlay con detalleMobile Home390 × 4800pxiPhone 14

🖥️ PANTALLAS Y COMPONENTES

1. TOPBAR
Frame: 1440 × 36px · Fondo: #0D3D28 · Texto: #9FE1CB · Font: DM Sans 12px
🚚  Envíos a todo el país  ·  Pedido mínimo $50.000  ·  Atención exclusiva mayorista  ·  0800-333-STOCK
Tip Figma: usar Auto Layout horizontal, justify center, padding 0 24px

2. HEADER / NAV
Frame: 1440 × 64px · Fondo: #FFFFFF · Sombra sticky activa al hacer scroll
Layout (de izquierda a derecha):
[LOGO]          [NAV LINKS]                    [BÚSQUEDA]    [CARRITO]   [INGRESAR]
TodoStock S.A.  Inicio  Productos▾  Ofertas     🔍___________  🛒 (3)     Ingresar
Logo: TodoStock en Syne 800, color #0D3D28 + S.A. en Syne 400, color #1A6B4A
Links de nav: Syne 600 · 13px · color #444 · hover: color #1A6B4A + underline 2px #1A6B4A
Search bar: bg #F4F4F0 · border 1px #D3D1C7 · radius 20px · width 200px · placeholder Buscar productos…
Botón carrito: bg #1A6B4A · color blanco · radius 20px · padding 8px 18px · badge rojo con número
Botón ingresar: border 1px #1A6B4A · color #1A6B4A · bg transparente · radius 8px · hover: bg #E8F5EE

3. DROPDOWN — "Productos" (frame separado + componente)
Tamaño: 240 × auto · bg #FFFFFF · border 1px #D3D1C7 · radius 8px · sombra dropdown
Interacción Figma: On Hover en el link "Productos" → Show overlay "Dropdown Productos" · posición: Below component · sin animación o slide down 200ms
Ítems del dropdown:
🧴  Detergentes y lavavajillas
🧹  Artículos de limpieza
🧼  Jabones y desengrasantes
💧  Desinfectantes y lavandinas
🗑️  Bolsas y descartables
🌿  Línea ecológica
────────────────────────
📦  Ver catálogo completo  →
Cada ítem: padding 10px 16px · 13px DM Sans · hover bg #E8F5EE · ícono en box 24×24 bg #F4F4F0 radius 4px

4. HERO
Frame: 1440 × 560px · bg degradado #0D3D28 → #1A6B4A · layout: 2 columnas
Columna izquierda (texto):
DISTRIBUCIÓN MAYORISTA DESDE 1998        ← label: Syne 11px, #9FE1CB, uppercase, tracking 1.5px

Tu proveedor de                          ← Syne 800, 52px, blanco
limpieza profesional                     ← Syne 800, 52px, color #5DCAA5

Precios directos para comercios,
empresas y revendedores de todo el país. ← DM Sans 16px, blanco 75% opacidad, max-width 420px

[Ver catálogo completo]  [Pedir por WhatsApp]
  bg #1A6B4A, blanco      border blanco, transparente
Columna derecha (estadísticas): grid 2×2 de cards
┌─────────────┐  ┌─────────────┐
│    +500     │  │    24hs     │
│  Productos  │  │  Despacho   │
└─────────────┘  └─────────────┘
┌─────────────┐  ┌─────────────┐
│    10%      │  │     5★      │
│  Desde 10   │  │  Garantía   │
│    cajas    │  │  de calidad │
└─────────────┘  └─────────────┘
Cards: bg rgba(255,255,255,0.10) · border 1px rgba(255,255,255,0.18) · radius 12px · número Syne 800 36px blanco · label DM Sans 12px opacidad 70%

5. BARRA DE FILTROS
Frame: 1440 × 52px · bg #FFFFFF · border-bottom 1px #D3D1C7 · overflow-x scroll en mobile
Chips (pills):
[Todos ✓]  [Detergentes]  [Desinfectantes]  [Artículos]  [Descartables]  [Ofertas 🔥]  [Línea Pro]
Estado default: bg #F4F4F0 · border 1px #D3D1C7 · color #444 · Syne 600 12px · radius 20px · padding 6px 16px
Estado activo: bg #1A6B4A · border #1A6B4A · color blanco
Interacción Figma: On Click → cambiar variante a "activo" (usar component variants)

6. SECCIÓN PRODUCTOS
Frame: 1440 × auto · bg #F4F4F0 · padding 48px 24px
Header de sección:
Más vendidos del mes                    Ver todos →
Syne 800 · 24px · #0D3D28             DM Sans 13px · #1A6B4A
Grid de cards: repeat(4, 1fr) · gap 16px
Anatomía de Product Card (240 × 320px · bg blanco · radius 12px · border 1px #D3D1C7):
┌──────────────────────┐
│  [MAYORISTA]         │  ← badge top-left, bg #E8F5EE, color #0D3D28
│                      │
│         🧴           │  ← imagen/emoji centrado, bg #F4F4F0, h 140px
│                      │
├──────────────────────┤
│ Detergente Indust. 5L│  ← Syne 600 · 13px · #2C2C2A
│ Caja × 4 unidades    │  ← DM Sans · 11px · #9B9B93
│                      │
│ $8.400    [+ Agregar]│  ← precio Syne 700 18px + botón verde
│ $2.100 c/u           │  ← DM Sans 11px · gris
└──────────────────────┘
Hover state: sombra 0 4px 20px rgba(0,0,0,0.10) · transform translateY(-2px) (en Figma: variante hover con sombra)
Badges disponibles:

MAYORISTA → bg #E8F5EE color #0D3D28
OFERTA → bg #FEF3E2 color #7A4A00
NUEVO → bg #E6F1FB color #0C447C
AGOTADO → bg #F4F4F0 color #9B9B93

Catálogo de productos para las cards:
#ProductoPresentaciónPrecioBadge1Detergente Industrial 5LCaja × 4u$8.400MAYORISTA2Lavandina Concentrada 4LPack × 6u$11.200OFERTA3Desengrasante Total 1LCaja × 12u$9.800MAYORISTA4Jabón en Polvo 10kgBolsa$6.500—5Esponja Doble FunciónPack × 24u$4.200NUEVO6Alcohol en Gel 500mlCaja × 12u$13.600OFERTA7Trapo de Piso ReforzadoPack × 10u$5.900MAYORISTA8Bolsas Consorcio 120LCaja × 100u$7.300—

7. BANNER PROMOCIONAL
Frame: 1392 × 96px · bg #0D3D28 · radius 12px · layout horizontal space-between · padding 0 32px
[Izquierda]                                          [Derecha]
🏷️  Comprá 10 cajas o más →  10% de descuento        [Aprovechar oferta →]
    automático en toda la tienda
    Syne 700 18px blanco  /  DM Sans 13px #9FE1CB     bg #F5A623 · Syne 700 · radius 8px

8. CARRITO LATERAL (Drawer)
Frame: 420 × 900px · posición right-0 · bg blanco · sombra −8px 0 32px rgba(0,0,0,0.15)
Interacción Figma: On Click en botón carrito → Open overlay "Drawer Carrito" · animación: slide in from right · bg overlay rgba(0,0,0,0.40)
Estructura:
┌─────────────────────────────────┐
│ Tu pedido               [✕]     │  ← Syne 700 20px / ícono cerrar
├─────────────────────────────────┤
│                                 │
│  🧴 Deterg. Industrial 5L       │
│     Caja × 4u         $8.400    │
│     [−]  1  [+]                 │
│                                 │
│  💧 Lavandina Conc. 4L          │
│     Pack × 6u         $11.200   │
│     [−]  2  [+]                 │
│                                 │
│  ─────────────────────────────  │
│  Subtotal:            $30.800   │  ← DM Sans 14px gris / Syne 700 18px verde
│  ⚠️ Mínimo $50.000 para envío   │  ← DM Sans 12px, badge amarillo
│                                 │
│  [    Finalizar pedido    ]     │  ← bg #1A6B4A, blanco, ancho completo
│  [    Seguir comprando    ]     │  ← border verde, transparente
└─────────────────────────────────┘

9. MODAL DETALLE DE PRODUCTO (overlay)
Frame: 640 × 480px · bg blanco · radius 16px · sombra fuerte
Interacción Figma: On Click en card → Open overlay "Modal Producto" · center screen · bg overlay rgba(0,0,0,0.50)
┌──────────────────────────────────────────────────────┐
│  [Imagen grande]    │  Detergente Industrial 5L  [✕] │
│                     │  Caja × 4 unidades             │
│  🧴 (240×280px)     │  ★★★★★  (48 reseñas)          │
│  bg #F4F4F0         │                                │
│                     │  $8.400 por caja               │
│                     │  $2.100 por unidad             │
│                     │                                │
│                     │  Cantidad:  [−] 1 [+]          │
│                     │                                │
│                     │  [+ Agregar al carrito]        │
│                     │  [🤝 Consultar por volumen]    │
│                     │                                │
│                     │  ✓ Stock disponible            │
│                     │  ✓ Envío en 24hs               │
└──────────────────────────────────────────────────────┘

10. SECCIÓN ¿POR QUÉ ELEGIRNOS?
Frame: 1440 × 280px · bg #FFFFFF · padding 48px 24px
Título: ¿Por qué elegir TodoStock S.A.? — Syne 800 28px centrado
Grid 4 columnas:
[🚚]              [💰]               [📦]               [🏆]
Envío rápido      Precio mayorista   Stock permanente   Calidad garantizada
24–48hs hábiles   Sin intermediarios +500 productos     Marcas líderes
Ícono en circle 56×56 bg #E8F5EE · Título Syne 600 15px · Desc DM Sans 13px gris · centrado

11. FOOTER
Frame: 1440 × 320px · bg #0D3D28 · color #9FE1CB
Grid 4 columnas:
Col 1 — Marca          Col 2 — Navegación    Col 3 — Contacto        Col 4 — Redes
TodoStock S.A.         Inicio                📞 0800-333-STOCK       [IG] Instagram
Distribución mayor-    Productos             ✉ ventas@todostock      [FB] Facebook
ista desde 1998.       Ofertas                 .com.ar               [WA] WhatsApp
Comprometidos con      Quiénes somos         📍 Buenos Aires, ARG
la calidad y el        Contacto              🕐 Lun–Vie 8–18hs
precio justo.
Pie de footer:
© 2025 TodoStock S.A. · Todos los derechos reservados · CUIT 30-71234567-8
DM Sans 12px · separador 1px rgba(255,255,255,0.15) arriba · centrado

🔗 FLUJO DE INTERACCIONES EN FIGMA
Frame: HOME
   │
   ├─ Hover en "Productos" ──────────→ Show overlay: DROPDOWN
   │
   ├─ Click en card de producto ─────→ Open overlay: MODAL PRODUCTO
   │
   ├─ Click en "+ Agregar" ──────────→ Variante botón "Agregado" + contador +1 en carrito
   │
   ├─ Click en ícono 🛒 ────────────→ Open overlay: DRAWER CARRITO (slide right)
   │
   ├─ Click en chip de filtro ───────→ Variante chip "activo" + cambio de grid
   │
   └─ Click en overlay oscuro ───────→ Close overlay activo

📱 MOBILE (390px) — ADAPTACIONES

Header: logo + hamburger ☰ + carrito
Menú hamburger → full screen overlay con links apilados
Hero: 1 columna, stats en fila scrolleable
Filtros: scroll horizontal
Grid productos: 2 columnas
Carrito: full screen (100vw × 100vh)