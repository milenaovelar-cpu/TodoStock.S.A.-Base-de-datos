interface ProductCardProps {
  id: number;
  name: string;
  presentation: string;
  price: number;
  unitPrice: number;
  badge?: 'MAYORISTA' | 'OFERTA' | 'NUEVO' | 'AGOTADO';
  emoji: string;
  onClick: () => void;
  onAddToCart: () => void;
}

export function ProductCard({
  name,
  presentation,
  price,
  unitPrice,
  badge,
  emoji,
  onClick,
  onAddToCart
}: ProductCardProps) {
  const badgeStyles = {
    MAYORISTA: 'bg-[#E8F5EE] text-[#0D3D28]',
    OFERTA: 'bg-[#FEF3E2] text-[#7A4A00]',
    NUEVO: 'bg-[#E6F1FB] text-[#0C447C]',
    AGOTADO: 'bg-[#F4F4F0] text-[#9B9B93]',
  };

  return (
    <div
      className="bg-white rounded-[12px] border border-[#D3D1C7] overflow-hidden cursor-pointer transition-all hover:shadow-[0_4px_20px_rgba(0,0,0,0.10)] hover:-translate-y-0.5"
      onClick={onClick}
    >
      {badge && (
        <div className="p-3">
          <span className={`px-2 py-1 rounded text-[10px] tracking-wider ${badgeStyles[badge]}`} style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600 }}>
            {badge}
          </span>
        </div>
      )}

      <div className="h-[140px] bg-[#F4F4F0] flex items-center justify-center text-6xl">
        {emoji}
      </div>

      <div className="p-4">
        <h3 className="text-[13px] text-[#2C2C2A] mb-1" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600 }}>
          {name}
        </h3>
        <p className="text-[11px] text-[#9B9B93] mb-3" style={{ fontFamily: 'DM Sans, sans-serif' }}>
          {presentation}
        </p>

        <div className="flex items-center justify-between">
          <div>
            <div className="text-[18px] text-[#1A6B4A]" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>
              ${price.toLocaleString('es-AR')}
            </div>
            <div className="text-[11px] text-[#9B9B93]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
              ${unitPrice.toLocaleString('es-AR')} c/u
            </div>
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onAddToCart();
            }}
            className="bg-[#1A6B4A] text-white px-4 py-2 rounded-[8px] text-[12px] hover:bg-[#0D3D28] transition-colors"
            style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600 }}
          >
            + Agregar
          </button>
        </div>
      </div>
    </div>
  );
}
