interface CartItem {
  id: number;
  name: string;
  presentation: string;
  price: number;
  emoji: string;
  quantity: number;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: number, quantity: number) => void;
}

export function CartDrawer({ isOpen, onClose, items, onUpdateQuantity }: CartDrawerProps) {
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const minOrder = 50000;
  const needsMore = subtotal < minOrder;

  if (!isOpen) return null;

  return (
    <>
      <div
        className="fixed inset-0 bg-black/40 z-40"
        onClick={onClose}
      />

      <div className="fixed right-0 top-0 h-full w-[420px] bg-white shadow-[-8px_0_32px_rgba(0,0,0,0.15)] z-50 flex flex-col">
        <div className="p-6 border-b border-[#D3D1C7] flex items-center justify-between">
          <h2 className="text-[20px] text-[#2C2C2A]" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>
            Tu pedido
          </h2>
          <button
            onClick={onClose}
            className="text-[#9B9B93] hover:text-[#2C2C2A] text-2xl"
          >
            ✕
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {items.length === 0 ? (
            <p className="text-center text-[#9B9B93] mt-8" style={{ fontFamily: 'DM Sans, sans-serif' }}>
              Tu carrito está vacío
            </p>
          ) : (
            <div className="space-y-4">
              {items.map((item) => (
                <div key={item.id} className="border-b border-[#D3D1C7] pb-4">
                  <div className="flex gap-3 mb-2">
                    <div className="text-2xl">{item.emoji}</div>
                    <div className="flex-1">
                      <h3 className="text-[14px] text-[#2C2C2A]" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600 }}>
                        {item.name}
                      </h3>
                      <p className="text-[12px] text-[#9B9B93]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                        {item.presentation}
                      </p>
                    </div>
                    <div className="text-[16px] text-[#1A6B4A]" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>
                      ${item.price.toLocaleString('es-AR')}
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => onUpdateQuantity(item.id, Math.max(0, item.quantity - 1))}
                      className="w-8 h-8 border border-[#D3D1C7] rounded flex items-center justify-center hover:bg-[#F4F4F0]"
                    >
                      −
                    </button>
                    <span className="text-[14px]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                      className="w-8 h-8 border border-[#D3D1C7] rounded flex items-center justify-center hover:bg-[#F4F4F0]"
                    >
                      +
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {items.length > 0 && (
          <div className="p-6 border-t border-[#D3D1C7] space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-[14px] text-[#9B9B93]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                Subtotal:
              </span>
              <span className="text-[18px] text-[#1A6B4A]" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>
                ${subtotal.toLocaleString('es-AR')}
              </span>
            </div>

            {needsMore && (
              <div className="bg-[#FEF3E2] border border-[#F5A623] rounded-lg p-3 flex items-start gap-2">
                <span className="text-[#7A4A00]">⚠️</span>
                <p className="text-[12px] text-[#7A4A00]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                  Mínimo ${minOrder.toLocaleString('es-AR')} para envío
                </p>
              </div>
            )}

            <button
              className="w-full bg-[#1A6B4A] text-white py-3 rounded-[8px] hover:bg-[#0D3D28] transition-colors"
              style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700 }}
            >
              Finalizar pedido
            </button>

            <button
              onClick={onClose}
              className="w-full border border-[#1A6B4A] text-[#1A6B4A] py-3 rounded-[8px] hover:bg-[#E8F5EE] transition-colors"
              style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600 }}
            >
              Seguir comprando
            </button>
          </div>
        )}
      </div>
    </>
  );
}
