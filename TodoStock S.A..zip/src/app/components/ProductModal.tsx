import * as React from 'react';

interface ProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: {
    id: number;
    name: string;
    presentation: string;
    price: number;
    unitPrice: number;
    emoji: string;
  } | null;
  onAddToCart: (quantity: number) => void;
}

export function ProductModal({ isOpen, onClose, product, onAddToCart }: ProductModalProps) {
  const [quantity, setQuantity] = React.useState(1);

  React.useEffect(() => {
    if (isOpen) {
      setQuantity(1);
    }
  }, [isOpen]);

  if (!isOpen || !product) return null;

  return (
    <>
      <div
        className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center"
        onClick={onClose}
      >
        <div
          className="bg-white rounded-[16px] w-[640px] max-h-[90vh] overflow-hidden shadow-[0_8px_32px_rgba(0,0,0,0.2)]"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex">
            <div className="w-[240px] bg-[#F4F4F0] flex items-center justify-center text-8xl p-8">
              {product.emoji}
            </div>

            <div className="flex-1 p-6 relative">
              <button
                onClick={onClose}
                className="absolute top-4 right-4 text-[#9B9B93] hover:text-[#2C2C2A] text-2xl"
              >
                ✕
              </button>

              <h2 className="text-[22px] text-[#2C2C2A] mb-2 pr-8" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>
                {product.name}
              </h2>

              <p className="text-[14px] text-[#9B9B93] mb-3" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                {product.presentation}
              </p>

              <div className="flex items-center gap-1 mb-4">
                <span className="text-[#F5A623]">★★★★★</span>
                <span className="text-[12px] text-[#9B9B93] ml-1" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                  (48 reseñas)
                </span>
              </div>

              <div className="mb-4">
                <div className="text-[24px] text-[#1A6B4A] mb-1" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>
                  ${product.price.toLocaleString('es-AR')} por caja
                </div>
                <div className="text-[14px] text-[#9B9B93]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                  ${product.unitPrice.toLocaleString('es-AR')} por unidad
                </div>
              </div>

              <div className="mb-4">
                <label className="text-[14px] text-[#2C2C2A] block mb-2" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600 }}>
                  Cantidad:
                </label>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 border border-[#D3D1C7] rounded flex items-center justify-center hover:bg-[#F4F4F0]"
                  >
                    −
                  </button>
                  <span className="text-[16px] min-w-[2rem] text-center" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-10 h-10 border border-[#D3D1C7] rounded flex items-center justify-center hover:bg-[#F4F4F0]"
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="space-y-2 mb-4">
                <button
                  onClick={() => {
                    onAddToCart(quantity);
                    onClose();
                  }}
                  className="w-full bg-[#1A6B4A] text-white py-3 rounded-[8px] hover:bg-[#0D3D28] transition-colors"
                  style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700 }}
                >
                  + Agregar al carrito
                </button>

                <button
                  className="w-full border border-[#1A6B4A] text-[#1A6B4A] py-3 rounded-[8px] hover:bg-[#E8F5EE] transition-colors"
                  style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600 }}
                >
                  🤝 Consultar por volumen
                </button>
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-2 text-[13px] text-[#1A6B4A]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                  <span>✓</span>
                  <span>Stock disponible</span>
                </div>
                <div className="flex items-center gap-2 text-[13px] text-[#1A6B4A]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                  <span>✓</span>
                  <span>Envío en 24hs</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
