import { useState } from 'react';
import { ProductCard } from './components/ProductCard';
import { CartDrawer } from './components/CartDrawer';
import { ProductModal } from './components/ProductModal';

interface Product {
  id: number;
  name: string;
  presentation: string;
  price: number;
  unitPrice: number;
  badge?: 'MAYORISTA' | 'OFERTA' | 'NUEVO' | 'AGOTADO';
  emoji: string;
  category: string;
}

interface CartItem {
  id: number;
  name: string;
  presentation: string;
  price: number;
  emoji: string;
  quantity: number;
}

const products: Product[] = [
  { id: 1, name: 'Detergente Industrial 5L', presentation: 'Caja × 4u', price: 8400, unitPrice: 2100, badge: 'MAYORISTA', emoji: '🧴', category: 'detergentes' },
  { id: 2, name: 'Lavandina Concentrada 4L', presentation: 'Pack × 6u', price: 11200, unitPrice: 1867, badge: 'OFERTA', emoji: '💧', category: 'desinfectantes' },
  { id: 3, name: 'Desengrasante Total 1L', presentation: 'Caja × 12u', price: 9800, unitPrice: 817, badge: 'MAYORISTA', emoji: '✨', category: 'detergentes' },
  { id: 4, name: 'Jabón en Polvo 10kg', presentation: 'Bolsa', price: 6500, unitPrice: 6500, emoji: '🧼', category: 'detergentes' },
  { id: 5, name: 'Esponja Doble Función', presentation: 'Pack × 24u', price: 4200, unitPrice: 175, badge: 'NUEVO', emoji: '🧽', category: 'articulos' },
  { id: 6, name: 'Alcohol en Gel 500ml', presentation: 'Caja × 12u', price: 13600, unitPrice: 1133, badge: 'OFERTA', emoji: '🧴', category: 'desinfectantes' },
  { id: 7, name: 'Trapo de Piso Reforzado', presentation: 'Pack × 10u', price: 5900, unitPrice: 590, badge: 'MAYORISTA', emoji: '🧹', category: 'articulos' },
  { id: 8, name: 'Bolsas Consorcio 120L', presentation: 'Caja × 100u', price: 7300, unitPrice: 73, emoji: '🗑️', category: 'descartables' },
];

export default function App() {
  const [cartOpen, setCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState('todos');

  const addToCart = (product: Product, quantity: number = 1) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, {
        id: product.id,
        name: product.name,
        presentation: product.presentation,
        price: product.price,
        emoji: product.emoji,
        quantity
      }];
    });
  };

  const updateQuantity = (id: number, quantity: number) => {
    if (quantity === 0) {
      setCartItems(prev => prev.filter(item => item.id !== id));
    } else {
      setCartItems(prev =>
        prev.map(item =>
          item.id === id ? { ...item, quantity } : item
        )
      );
    }
  };

  const cartItemCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const filteredProducts = activeFilter === 'todos'
    ? products
    : products.filter(p => p.category === activeFilter);

  return (
    <div className="min-h-screen bg-[#F4F4F0]">
      {/* Topbar */}
      <div className="bg-[#0D3D28] text-[#9FE1CB] py-2">
        <div className="container mx-auto px-6 text-center text-[12px]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
          🚚 Envíos a todo el país · Pedido mínimo $50.000 · Atención exclusiva mayorista · 0800-333-STOCK
        </div>
      </div>

      {/* Header */}
      <header className="bg-white border-b border-[#D3D1C7] sticky top-0 z-30 shadow-[0_2px_8px_rgba(0,0,0,0.08)]">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="text-[24px]" style={{ fontFamily: 'Syne, sans-serif' }}>
            <span className="text-[#0D3D28]" style={{ fontWeight: 800 }}>TodoStock</span>
            <span className="text-[#1A6B4A]" style={{ fontWeight: 400 }}> S.A.</span>
          </div>

          <nav className="flex items-center gap-6">
            <a href="#" className="text-[13px] text-[#444] hover:text-[#1A6B4A] transition-colors" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600 }}>
              Inicio
            </a>
            <div
              className="relative"
              onMouseEnter={() => setDropdownOpen(true)}
              onMouseLeave={() => setDropdownOpen(false)}
            >
              <a href="#" className="text-[13px] text-[#444] hover:text-[#1A6B4A] transition-colors" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600 }}>
                Productos ▾
              </a>
              {dropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-[240px] bg-white border border-[#D3D1C7] rounded-[8px] shadow-[0_8px_24px_rgba(0,0,0,0.12)] py-2">
                  <a href="#" className="flex items-center gap-3 px-4 py-2 hover:bg-[#E8F5EE] text-[13px]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                    <span className="w-6 h-6 bg-[#F4F4F0] rounded flex items-center justify-center">🧴</span>
                    Detergentes y lavavajillas
                  </a>
                  <a href="#" className="flex items-center gap-3 px-4 py-2 hover:bg-[#E8F5EE] text-[13px]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                    <span className="w-6 h-6 bg-[#F4F4F0] rounded flex items-center justify-center">🧹</span>
                    Artículos de limpieza
                  </a>
                  <a href="#" className="flex items-center gap-3 px-4 py-2 hover:bg-[#E8F5EE] text-[13px]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                    <span className="w-6 h-6 bg-[#F4F4F0] rounded flex items-center justify-center">🧼</span>
                    Jabones y desengrasantes
                  </a>
                  <a href="#" className="flex items-center gap-3 px-4 py-2 hover:bg-[#E8F5EE] text-[13px]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                    <span className="w-6 h-6 bg-[#F4F4F0] rounded flex items-center justify-center">💧</span>
                    Desinfectantes y lavandinas
                  </a>
                  <a href="#" className="flex items-center gap-3 px-4 py-2 hover:bg-[#E8F5EE] text-[13px]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                    <span className="w-6 h-6 bg-[#F4F4F0] rounded flex items-center justify-center">🗑️</span>
                    Bolsas y descartables
                  </a>
                  <a href="#" className="flex items-center gap-3 px-4 py-2 hover:bg-[#E8F5EE] text-[13px]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                    <span className="w-6 h-6 bg-[#F4F4F0] rounded flex items-center justify-center">🌿</span>
                    Línea ecológica
                  </a>
                  <hr className="my-2 border-[#D3D1C7]" />
                  <a href="#" className="flex items-center justify-between px-4 py-2 hover:bg-[#E8F5EE] text-[13px] text-[#1A6B4A]" style={{ fontFamily: 'DM Sans, sans-serif', fontWeight: 600 }}>
                    📦 Ver catálogo completo
                    <span>→</span>
                  </a>
                </div>
              )}
            </div>
            <a href="#" className="text-[13px] text-[#444] hover:text-[#1A6B4A] transition-colors" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600 }}>
              Ofertas
            </a>
          </nav>

          <div className="flex items-center gap-4">
            <input
              type="text"
              placeholder="Buscar productos..."
              className="bg-[#F4F4F0] border border-[#D3D1C7] rounded-[20px] px-4 py-2 w-[200px] text-[13px]"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            />

            <button
              onClick={() => setCartOpen(true)}
              className="bg-[#1A6B4A] text-white rounded-[20px] px-4 py-2 flex items-center gap-2 hover:bg-[#0D3D28] transition-colors relative"
              style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600 }}
            >
              🛒
              {cartItemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-[#E8453C] text-white rounded-full w-6 h-6 flex items-center justify-center text-[11px]">
                  {cartItemCount}
                </span>
              )}
            </button>

            <button className="border border-[#1A6B4A] text-[#1A6B4A] bg-transparent rounded-[8px] px-4 py-2 hover:bg-[#E8F5EE] transition-colors text-[13px]" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600 }}>
              Ingresar
            </button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="bg-gradient-to-r from-[#0D3D28] to-[#1A6B4A] py-16">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 gap-12 items-center">
            <div>
              <div className="text-[#9FE1CB] text-[11px] uppercase mb-4" style={{ fontFamily: 'Syne, sans-serif', letterSpacing: '1.5px' }}>
                DISTRIBUCIÓN MAYORISTA DESDE 1998
              </div>
              <h1 className="text-[52px] leading-tight mb-4" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800 }}>
                <span className="text-white">Tu proveedor de</span>
                <br />
                <span className="text-[#5DCAA5]">limpieza profesional</span>
              </h1>
              <p className="text-white/75 text-[16px] max-w-[420px] mb-8" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                Precios directos para comercios, empresas y revendedores de todo el país.
              </p>
              <div className="flex gap-4">
                <button className="bg-[#1A6B4A] text-white px-6 py-3 rounded-[8px] hover:bg-[#0D3D28] transition-colors" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>
                  Ver catálogo completo
                </button>
                <button className="border border-white text-white px-6 py-3 rounded-[8px] hover:bg-white/10 transition-colors" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>
                  Pedir por WhatsApp
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {[
                { number: '+500', label: 'Productos' },
                { number: '24hs', label: 'Despacho' },
                { number: '10%', label: 'Desde 10 cajas' },
                { number: '5★', label: 'Garantía de calidad' },
              ].map((stat, i) => (
                <div key={i} className="bg-white/10 border border-white/[0.18] rounded-[12px] p-6 text-center">
                  <div className="text-white text-[36px] mb-1" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800 }}>
                    {stat.number}
                  </div>
                  <div className="text-white/70 text-[12px]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Filter Bar */}
      <div className="bg-white border-b border-[#D3D1C7] overflow-x-auto">
        <div className="container mx-auto px-6 py-3">
          <div className="flex gap-2">
            {[
              { id: 'todos', label: 'Todos ✓' },
              { id: 'detergentes', label: 'Detergentes' },
              { id: 'desinfectantes', label: 'Desinfectantes' },
              { id: 'articulos', label: 'Artículos' },
              { id: 'descartables', label: 'Descartables' },
              { id: 'ofertas', label: 'Ofertas 🔥' },
            ].map(filter => (
              <button
                key={filter.id}
                onClick={() => setActiveFilter(filter.id)}
                className={`px-4 py-1.5 rounded-[20px] text-[12px] whitespace-nowrap transition-colors ${
                  activeFilter === filter.id
                    ? 'bg-[#1A6B4A] border-[#1A6B4A] text-white'
                    : 'bg-[#F4F4F0] border border-[#D3D1C7] text-[#444] hover:bg-[#E8F5EE]'
                }`}
                style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600 }}
              >
                {filter.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Products Section */}
      <section className="py-12">
        <div className="container mx-auto px-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-[24px] text-[#0D3D28]" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800 }}>
              Más vendidos del mes
            </h2>
            <a href="#" className="text-[13px] text-[#1A6B4A] hover:underline" style={{ fontFamily: 'DM Sans, sans-serif' }}>
              Ver todos →
            </a>
          </div>

          <div className="grid grid-cols-4 gap-4">
            {filteredProducts.map(product => (
              <ProductCard
                key={product.id}
                {...product}
                onClick={() => setSelectedProduct(product)}
                onAddToCart={() => addToCart(product)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Promotional Banner */}
      <section className="py-8">
        <div className="container mx-auto px-6">
          <div className="bg-[#0D3D28] rounded-[12px] px-8 py-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <span className="text-4xl">🏷️</span>
              <div>
                <div className="text-white text-[18px] mb-1" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>
                  Comprá 10 cajas o más → 10% de descuento automático
                </div>
                <div className="text-[#9FE1CB] text-[13px]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                  en toda la tienda
                </div>
              </div>
            </div>
            <button className="bg-[#F5A623] text-white px-6 py-3 rounded-[8px] hover:bg-[#d99420] transition-colors" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>
              Aprovechar oferta →
            </button>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="bg-white py-12">
        <div className="container mx-auto px-6">
          <h2 className="text-[28px] text-center mb-12 text-[#0D3D28]" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800 }}>
            ¿Por qué elegir TodoStock S.A.?
          </h2>

          <div className="grid grid-cols-4 gap-8">
            {[
              { emoji: '🚚', title: 'Envío rápido', desc: '24–48hs hábiles' },
              { emoji: '💰', title: 'Precio mayorista', desc: 'Sin intermediarios' },
              { emoji: '📦', title: 'Stock permanente', desc: '+500 productos' },
              { emoji: '🏆', title: 'Calidad garantizada', desc: 'Marcas líderes' },
            ].map((feature, i) => (
              <div key={i} className="text-center">
                <div className="w-14 h-14 bg-[#E8F5EE] rounded-full flex items-center justify-center text-2xl mx-auto mb-4">
                  {feature.emoji}
                </div>
                <h3 className="text-[15px] text-[#2C2C2A] mb-1" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600 }}>
                  {feature.title}
                </h3>
                <p className="text-[13px] text-[#9B9B93]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                  {feature.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#0D3D28] text-[#9FE1CB] py-12">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-white text-[16px] mb-4" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>
                TodoStock S.A.
              </h3>
              <p className="text-[13px] leading-relaxed" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                Distribución mayorista desde 1998. Comprometidos con la calidad y el precio justo.
              </p>
            </div>

            <div>
              <h3 className="text-white text-[14px] mb-4" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600 }}>
                Navegación
              </h3>
              <ul className="space-y-2 text-[13px]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                <li><a href="#" className="hover:text-white">Inicio</a></li>
                <li><a href="#" className="hover:text-white">Productos</a></li>
                <li><a href="#" className="hover:text-white">Ofertas</a></li>
                <li><a href="#" className="hover:text-white">Quiénes somos</a></li>
                <li><a href="#" className="hover:text-white">Contacto</a></li>
              </ul>
            </div>

            <div>
              <h3 className="text-white text-[14px] mb-4" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600 }}>
                Contacto
              </h3>
              <ul className="space-y-2 text-[13px]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                <li>📞 0800-333-STOCK</li>
                <li>✉ ventas@todostock.com.ar</li>
                <li>📍 Buenos Aires, ARG</li>
                <li>🕐 Lun–Vie 8–18hs</li>
              </ul>
            </div>

            <div>
              <h3 className="text-white text-[14px] mb-4" style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600 }}>
                Redes
              </h3>
              <ul className="space-y-2 text-[13px]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                <li><a href="#" className="hover:text-white">Instagram</a></li>
                <li><a href="#" className="hover:text-white">Facebook</a></li>
                <li><a href="#" className="hover:text-white">WhatsApp</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-white/15 pt-6 text-center text-[12px]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
            © 2025 TodoStock S.A. · Todos los derechos reservados · CUIT 30-71234567-8
          </div>
        </div>
      </footer>

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={updateQuantity}
      />

      {/* Product Modal */}
      <ProductModal
        isOpen={!!selectedProduct}
        onClose={() => setSelectedProduct(null)}
        product={selectedProduct}
        onAddToCart={(quantity) => selectedProduct && addToCart(selectedProduct, quantity)}
      />
    </div>
  );
}
