
  # TodoStock S.A. Wholesale App

  This is a code bundle for TodoStock S.A. Wholesale App. The original project is available at https://www.figma.com/design/rxpXHIccnyKjuL3mRi1hxh/TodoStock-S.A.-Wholesale-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  